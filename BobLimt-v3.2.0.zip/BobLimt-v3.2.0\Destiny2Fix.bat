@echo off
setlocal enabledelayedexpansion
title Destiny 2 Fix
color 0B

set "APPID=1085660"
set "STATEPATH=%ProgramData%\Destiny2Fix"
set "MODE=APPLY"
if /i "%~1"=="/revert" set "MODE=REVERT"
if /i "%~1"=="/status" set "MODE=STATUS"

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator rights...
    set "D2FIX_SCRIPT=%~f0"
    set "D2FIX_ARG=%~1"
    powershell -NoProfile -Command "Start-Process -FilePath $env:D2FIX_SCRIPT -ArgumentList $env:D2FIX_ARG -Verb RunAs"
    exit /b
)

echo.
echo  =====================================================
echo    Destiny 2 Fix   [!MODE!]
echo  =====================================================
echo.

set "STEAMPATH="
for /f "tokens=2,*" %%a in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul') do set "STEAMPATH=%%b"
if not defined STEAMPATH for /f "tokens=2,*" %%a in ('reg query "HKLM\SOFTWARE\WOW6432Node\Valve\Steam" /v InstallPath 2^>nul') do set "STEAMPATH=%%b"
if not defined STEAMPATH for /f "tokens=2,*" %%a in ('reg query "HKLM\SOFTWARE\Valve\Steam" /v InstallPath 2^>nul') do set "STEAMPATH=%%b"
set "STEAMPATH=!STEAMPATH:/=\!"
if "!STEAMPATH:~-1!"=="\" set "STEAMPATH=!STEAMPATH:~0,-1!"

if not exist "!STEAMPATH!\steam.exe" (
    echo  [X] Steam was not found. Detected path: "!STEAMPATH!"
    echo      This requires a normal registered Steam installation.
    goto :done
)
echo  [+] Steam: !STEAMPATH!
echo.

set "T1=!STEAMPATH!\GameOverlayRenderer.dll"
set "T2=!STEAMPATH!\GameOverlayRenderer64.dll"
set "T3=!STEAMPATH!\GameOverlayUI.exe"
set "T4=!STEAMPATH!\gameoverlayui64.exe"
set "T5=!STEAMPATH!\SteamOverlayVulkanLayer.dll"
set "T6=!STEAMPATH!\SteamOverlayVulkanLayer64.dll"
set "T7=!STEAMPATH!\SteamOverlayVulkanLayer.json"
set "T8=!STEAMPATH!\SteamOverlayVulkanLayer64.json"
set "T9=!STEAMPATH!\bin\gameoverlayui.exe"
set "COUNT=9"

if "!MODE!"=="STATUS" goto :status
if "!MODE!"=="REVERT" goto :revert

echo  Closing Steam...
taskkill /f /im steam.exe            >nul 2>&1
taskkill /f /im steamwebhelper.exe   >nul 2>&1
taskkill /f /im steamservice.exe     >nul 2>&1
taskkill /f /im GameOverlayUI.exe    >nul 2>&1
taskkill /f /im gameoverlayui64.exe  >nul 2>&1

set /a WAIT=0
:waitloop
tasklist /fi "imagename eq steam.exe" 2>nul | find /i "steam.exe" >nul
if !errorlevel! neq 0 goto :closed
set /a WAIT+=1
if !WAIT! gtr 20 goto :closed
timeout /t 1 /nobreak >nul
goto :waitloop
:closed
timeout /t 2 /nobreak >nul
echo  [+] Steam closed.
echo.

echo  Blocking Steam overlay hooks...
for /l %%i in (1,1,%COUNT%) do call :block "!T%%i!"

if not exist "!STATEPATH!" md "!STATEPATH!" >nul 2>&1
if not exist "!STATEPATH!\SteamOverlayValue.txt" (
    set "PRIORSTEAM=MISSING"
    for /f "tokens=3" %%v in ('reg query "HKCU\Software\Valve\Steam" /v EnableGameOverlay 2^>nul ^| find /i "EnableGameOverlay"') do set "PRIORSTEAM=%%v"
    >"!STATEPATH!\SteamOverlayValue.txt" echo !PRIORSTEAM!
)
reg add "HKCU\Software\Valve\Steam" /v EnableGameOverlay /t REG_DWORD /d 0 /f >nul 2>&1
echo  [+] Steam Overlay registry flag disabled.
echo.

reg query "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode >nul 2>&1
if !errorlevel! equ 0 (
    echo  [+] Windows MPO is already disabled.
) else (
    choice /c YN /n /m "  Also disable Windows MPO? This needs a reboot. [Y/N] "
    if !errorlevel! equ 1 (
        reg add "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /t REG_DWORD /d 5 /f >nul
        >"!STATEPATH!\MpoChangedByTool.flag" echo 5
        echo  [+] MPO disabled. Reboot later to apply it.
        set "NEEDREBOOT=1"
    ) else echo  [-] MPO left unchanged.
)
echo.

set "NVKEY=HKCU\SOFTWARE\NVIDIA Corporation\Global\ShadowPlay\NVSHARE"
set "NVIDIACURRENT=0x1"
reg query "!NVKEY!" /v Enable >nul 2>&1
if !errorlevel! equ 0 (
    for /f "tokens=3" %%v in ('reg query "!NVKEY!" /v Enable 2^>nul ^| find /i "Enable"') do set "NVIDIACURRENT=%%v"
)
if /i "!NVIDIACURRENT!"=="0x0" (
    echo  [+] NVIDIA Overlay is already disabled.
) else (
    choice /c YN /n /m "  Also disable NVIDIA Overlay (Alt+Z)? [Y/N] "
    if !errorlevel! equ 1 (
        if not exist "!STATEPATH!\NvidiaOverlayValue.txt" (
            >"!STATEPATH!\NvidiaOverlayValue.txt" echo !NVIDIACURRENT!
        )
        taskkill /f /im "NVIDIA Share.exe" >nul 2>&1
        reg add "!NVKEY!" /v Enable /t REG_DWORD /d 0 /f >nul 2>&1
        echo  [+] NVIDIA Overlay disabled.
    ) else echo  [-] NVIDIA Overlay left unchanged.
)
echo.

echo  Verifying blocked hooks...
set /a OK=0
set /a BAD=0
for /l %%i in (1,1,%COUNT%) do call :check "!T%%i!"
echo.
if !BAD! equ 0 (echo  [+] All !OK! hooks are blocked.) else echo  [!] !OK! blocked, !BAD! need attention.

echo.
echo  Launching Destiny 2...
start "" explorer.exe "steam://rungameid/%APPID%"
if defined NEEDREBOOT echo  [!] Reboot later for the MPO change.
goto :done

:revert
echo  Closing Steam...
taskkill /f /im steam.exe          >nul 2>&1
taskkill /f /im steamwebhelper.exe >nul 2>&1
timeout /t 3 /nobreak >nul
echo  Removing overlay blocks...
for /l %%i in (1,1,%COUNT%) do call :unblock "!T%%i!"
if exist "!STATEPATH!\SteamOverlayValue.txt" (
    set /p PRIORSTEAM=<"!STATEPATH!\SteamOverlayValue.txt"
    if /i "!PRIORSTEAM!"=="MISSING" (
        reg delete "HKCU\Software\Valve\Steam" /v EnableGameOverlay /f >nul 2>&1
    ) else (
        reg add "HKCU\Software\Valve\Steam" /v EnableGameOverlay /t REG_DWORD /d !PRIORSTEAM! /f >nul 2>&1
    )
    del /q "!STATEPATH!\SteamOverlayValue.txt" >nul 2>&1
) else reg delete "HKCU\Software\Valve\Steam" /v EnableGameOverlay /f >nul 2>&1
if exist "!STATEPATH!\MpoChangedByTool.flag" (
    reg delete "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /f >nul 2>&1
    del /q "!STATEPATH!\MpoChangedByTool.flag" >nul 2>&1
    echo  [+] Restored MPO to its previous state.
) else echo  [-] MPO was not changed by this bundle; left unchanged.
if exist "!STATEPATH!\NvidiaOverlayValue.txt" (
    set /p PRIORNVIDIA=<"!STATEPATH!\NvidiaOverlayValue.txt"
    reg add "HKCU\SOFTWARE\NVIDIA Corporation\Global\ShadowPlay\NVSHARE" /v Enable /t REG_DWORD /d !PRIORNVIDIA! /f >nul 2>&1
    del /q "!STATEPATH!\NvidiaOverlayValue.txt" >nul 2>&1
    echo  [+] Restored NVIDIA Overlay to its previous state.
) else echo  [-] NVIDIA Overlay was not changed by this bundle; left unchanged.
echo.
echo  [+] Reverted. Steam will redownload its overlay files.
echo      Re-enable Steam Overlay in Steam Settings if desired.
echo      Reboot to restore MPO behavior.
goto :done

:status
echo  Current state:
for /l %%i in (1,1,%COUNT%) do call :check "!T%%i!"
echo.
reg query "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode >nul 2>&1
if !errorlevel! equ 0 (echo  MPO ............................... DISABLED) else echo  MPO ............................... active
reg query "HKCU\SOFTWARE\NVIDIA Corporation\Global\ShadowPlay\NVSHARE" /v Enable >nul 2>&1
if !errorlevel! neq 0 (
    echo  NVIDIA Overlay ..................... not configured
) else (
    for /f "tokens=3" %%v in ('reg query "HKCU\SOFTWARE\NVIDIA Corporation\Global\ShadowPlay\NVSHARE" /v Enable 2^>nul ^| find /i "Enable"') do set "NVSTATUS=%%v"
    if /i "!NVSTATUS!"=="0x0" (echo  NVIDIA Overlay ..................... DISABLED) else echo  NVIDIA Overlay ..................... active
)
goto :done

:block
set "F=%~1"
set "N=%~nx1"
if not exist "%~dp1" (
    echo   -  !N!  ^(folder missing, skipped^)
    goto :eof
)
attrib -R -S -H "!F!" >nul 2>&1
icacls "!F!" /reset >nul 2>&1
del /f /q "!F!" >nul 2>&1
if exist "!F!" (
    echo   X  !N!  ^(locked - Steam may still be running^)
    goto :eof
)
type nul > "!F!" 2>nul
if not exist "!F!" (
    echo   X  !N!  ^(could not create placeholder^)
    goto :eof
)
icacls "!F!" /inheritance:r /grant:r "*S-1-1-0:(RX)" >nul 2>&1
icacls "!F!" /deny "*S-1-1-0:(W,D)" >nul 2>&1
attrib +R "!F!" >nul 2>&1
echo   +  !N!
goto :eof

:unblock
set "F=%~1"
set "N=%~nx1"
if not exist "!F!" (
    echo   -  !N!  ^(not present^)
    goto :eof
)
attrib -R "!F!" >nul 2>&1
takeown /f "!F!" >nul 2>&1
icacls "!F!" /reset >nul 2>&1
icacls "!F!" /grant "*S-1-5-32-544:(F)" >nul 2>&1
del /f /q "!F!" >nul 2>&1
if exist "!F!" (echo   X  !N!  ^(still locked^)) else echo   +  !N!  restored
goto :eof

:check
set "F=%~1"
set "N=%~nx1"
set "PAD=!N!                                   "
set "PAD=!PAD:~0,34!"
if not exist "!F!" (
    echo   !PAD! MISSING  ^(Steam can recreate it^)
    set /a BAD+=1
    goto :eof
)
if %~z1 equ 0 (
    echo   !PAD! blocked
    set /a OK+=1
) else (
    echo   !PAD! ACTIVE   ^(%~z1 bytes^)
    set /a BAD+=1
)
goto :eof

:done
echo.
if /i "!MODE!"=="APPLY" (
    timeout /t 5 /nobreak >nul
) else (
    pause
)
endlocal
